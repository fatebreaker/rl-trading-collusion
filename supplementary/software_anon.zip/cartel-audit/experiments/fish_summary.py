"""The protocol of Fish et al. (EC'26) audited: competence screen (a lone agent
against a rival fixed at the monopoly price), then duopolies with prompt prefixes
P1 and P2, a myopic placebo and prices x10, each with paired deviation tests and
the on-path regression of their Table 1. Reads results/llm_fish/*.json and
results/fish_regression.json; writes results/fish_summary.json,
paper/numbers_fish.tex and paper/table_fish.tex.

    python experiments/fish_summary.py
"""
from __future__ import annotations

import json
import os

import numpy as np
from scipy import stats

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
RES = os.path.join(ROOT, "results", "llm_fish")
PI_RATIO = 0.33749 / 0.22296  # monopoly / Nash profit
MODELS = {"gptoss20b": ("gpt-oss-20b", "Oss"), "gptoss120b": ("gpt-oss-120b", "OssBig"),
          "gpt52_high": ("GPT-5.2, high effort", "GptFive"), "qwen3_32b": ("Qwen3-32B", "QwenBig")}
CONDS = {"duopoly_P1": ("P1", "POne"), "duopoly_P2": ("P2", "PTwo"),
         "myopic_P1": ("P1, myopic", "Myopic"), "duopoly_P1_k10": ("P1, prices $\\times10$", "Ten")}


def load(name):
    f = os.path.join(RES, f"{name}.json")
    return json.load(open(f)) if os.path.exists(f) and os.path.getsize(f) > 0 else None


def ci(a):
    """Mean and half-width of a 95% t interval across sessions."""
    a = np.asarray(a, float)
    return float(a.mean()), float(stats.t.ppf(0.975, len(a) - 1) * a.std(ddof=1) / np.sqrt(len(a)))


def main():
    reg = json.load(open(os.path.join(ROOT, "results", "fish_regression.json")))
    out, macros, rows = {}, {}, []
    for tag, (mname, mkey) in MODELS.items():
        solo = load(f"{tag}_solo_P1") or load(f"{tag}_solo_P1_pilot")
        if solo:
            out[f"{tag}_solo"] = solo["solo"]
            macros[f"Fish{mkey}Gap"] = f"{abs(solo['solo']['gap']) if abs(solo['solo']['gap']) < 0.005 else solo['solo']['gap']:.2f}"
            macros[f"Fish{mkey}BRShare"] = f"{100 * solo['solo']['profit_share_of_br']:.0f}"
        for cond, (cname, ckey) in CONDS.items():
            d = load(f"{tag}_{cond}")
            if d is None:
                continue
            idx = ci(d["per_session"]["index"])
            pidx = ci((np.asarray(d["per_session"]["profit_over_nash"]) - 1) / (PI_RATIO - 1))
            r = {"index": idx, "profit_index": pidx, "fail": d["parse_fail_rate"]}
            dv = d.get("deviation")
            if dv:  # best-response deviation: raw response (fall in the rival's price, index units)
                r.update(br_response=(dv["rival_aggression"][1], dv["rival_aggression_ci95"][1]),
                         br_size=dv["deviation_size"], gain=(dv["cum_gain_dev"], dv["cum_gain_dev_ci95"]))
                if dv["deviation_size"] >= 0.1:  # a sizeable cut: response per unit, at lag 1 and summed
                    u = dv["deviation_size"]
                    H = min(6, len(dv["rival_aggression"]) - 1)
                    r.update(br_per_unit=(dv["rival_aggression"][1] / u, dv["rival_aggression_ci95"][1] / u),
                             br_per_unit_mean6=sum(dv["rival_aggression"][1:H + 1]) / H / u)
            dc = d.get("deviation_cut")
            if dc and dc["deviation_size"] >= 0.1:  # visible 10% cut: per unit of the cut
                r.update(response=(dc["rival_aggression"][1] / dc["deviation_size"],
                                   dc["rival_aggression_ci95"][1] / dc["deviation_size"]),
                         cut_gain=(dc["cum_gain_dev"], dc["cum_gain_dev_ci95"]))
            g = reg.get(f"{tag}_{cond}")
            if g:  # exact best-response benchmarks at the run's prices (fish_regression.py)
                r.update(br_slope=g["br_slope"], cut_slope=g["cut_slope"], brdev_slope=g["brdev_slope"])
                if g["delta_se"] > 1e-8:  # prices that barely move make the regression degenerate
                    S = len(d["per_session"]["index"])  # standard errors clustered by session
                    r.update(delta=(g["delta"], stats.t.ppf(0.975, S - 1) * g["delta_se"]))
            out[f"{tag}_{cond}"] = r
            key = f"Fish{mkey}{ckey}"
            macros[f"{key}Idx"] = f"{idx[0]:.2f}"
            macros[f"{key}IdxCI"] = f"{idx[1]:.2f}"
            macros[f"{key}Prof"] = f"{pidx[0]:.2f}"
            if "br_response" in r:
                macros[f"{key}BRResp"] = f"{r['br_response'][0]:.2f}\\pm{r['br_response'][1]:.2f}"
                macros[f"{key}Gain"] = f"{r['gain'][0]:+.2f}\\pm{r['gain'][1]:.2f}"
                macros[f"{key}BRSize"] = f"{r['br_size']:.2f}"
            if "br_per_unit" in r:
                macros[f"{key}BRUnit"] = f"{r['br_per_unit'][0]:.2f}\\pm{r['br_per_unit'][1]:.2f}"
                macros[f"{key}BRUnitMean"] = f"{r['br_per_unit'][0]:.2f}"
                macros[f"{key}BRUnitSix"] = f"{r['br_per_unit_mean6']:.2f}"
            if "response" in r:
                macros[f"{key}Resp"] = f"{r['response'][0]:.2f}\\pm{r['response'][1]:.2f}"
                macros[f"{key}CutGain"] = f"{r['cut_gain'][0]:+.2f}\\pm{r['cut_gain'][1]:.2f}"
            if "br_slope" in r:
                macros[f"{key}BR"] = f"{r['br_slope']:.2f}"
                macros[f"{key}CutBR"] = f"{r['cut_slope']:.2f}"
                macros[f"{key}BRDev"] = f"{r['brdev_slope']:.2f}"
            if "delta" in r:
                macros[f"{key}Reg"] = f"{r['delta'][0]:.2f}"
            rows.append((mname, cname, r))
    json.dump(out, open(os.path.join(ROOT, "results", "fish_summary.json"), "w"), indent=1)
    os.makedirs(os.path.join(ROOT, "paper"), exist_ok=True)
    with open(os.path.join(ROOT, "paper", "numbers_fish.tex"), "w") as fh:
        fh.write("% generated by experiments/fish_summary.py\n")
        for k, v in macros.items():
            fh.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")
    pm = lambda t, sgn="": "--" if t is None else f"${t[0]:{sgn}.2f}_{{\\pm{t[1]:.2f}}}$"  # noqa: E731
    L = ["\\begin{tabular}{@{}llccccccccc@{}}", "\\toprule",
         " & & price & profit & \\multicolumn{3}{c}{best-response deviation} & \\multicolumn{2}{c}{$10\\%$ cut}"
         " & on-path & best-resp. \\\\",
         "\\cmidrule(lr){5-7}\\cmidrule(lr){8-9}",
         "Model & Prompt & index & index & size & rival & gain & rival per unit (BR) & gain & coefficient & slope \\\\",
         "\\midrule"]
    for mname, cname, r in rows:
        if "br_per_unit" in r:  # sizeable deviation: response per unit of the cut
            br = pm(r["br_per_unit"]) + "$^\\ast$"
        else:
            br = pm(r.get("br_response"))
        size = f"${r['br_size']:.2f}$" if "br_size" in r else "--"
        cut = pm(r.get("response"))
        if "response" in r and "cut_slope" in r:  # what a rival that only best-responds would follow
            cut += f" (${r['cut_slope']:.2f}$)"
        L.append(" & ".join([mname, cname, pm(r["index"]), pm(r["profit_index"]), size, br,
                             pm(r.get("gain"), "+"), cut, pm(r.get("cut_gain"), "+"), pm(r.get("delta")),
                             f"${r['br_slope']:.2f}$" if "br_slope" in r else "--"]) + " \\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    open(os.path.join(ROOT, "paper", "table_fish.tex"), "w").write("\n".join(L) + "\n")
    print(json.dumps(out, indent=1, default=str)[:2500])


if __name__ == "__main__":
    main()
