"""Symmetric deviation tests (Epivent and Lambin, 2024): an upward one-period
deviation (a 10% price rise) next to the usual downward ones, for the Calvano
Q-learners (trained as in bertrand_validation.py, baseline and myopic) and for
the LLM pricing agents (results/llm_bertrand_hike, run with --dev-hike 0.1).
Q-learners that punish cuts may also start price wars after rises; an agent
that only follows prices moves with the deviator in both directions.

Writes results/hike_test.json and paper/numbers_hike.tex.

    PYTHONPATH=src python experiments/hike_test.py
"""
from __future__ import annotations

import json
import math
import os
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from kylecollusion.bertrand import BertrandConfig, BertrandMarket, BertrandQ, deviation_response, evaluate, train  # noqa: E402

SESSIONS, STEPS, SEED = 100, 2_500_000, 0  # as bertrand_validation.py
HIKE = 0.10


def per_unit(d):
    """Rival's lag-1 price change per unit of the deviator's price change."""
    return d["d_price_rival"][1] / d["d_price_dev"][0], abs(d["d_price_rival_ci95"][1] / d["d_price_dev"][0])


def qlearners(out):
    for name, gamma in (("baseline", 0.95), ("myopic", 0.0)):
        if name in out:
            continue
        env = BertrandMarket(BertrandConfig(), SESSIONS, seed=SEED)
        ag = BertrandQ(env, gamma=gamma, seed=SEED, update="taken", alpha=0.15, beta_decay=4e-6)
        s, _ = train(env, ag, STEPS)
        _, _, s = evaluate(env, ag, s)
        r = {}
        for mode, kw in (("best_response", {}), ("hike", {"hike": HIKE})):
            d = deviation_response(copy_env(env), ag, s.copy(), deviator=0, **kw)
            m, c = per_unit(d)
            r[mode] = {**d, "per_unit": m, "per_unit_ci95": c}
            print(f"Q-learning {name} {mode}: deviator dp {d['d_price_dev'][0]:+.3f}, rival lag-1 "
                  f"{d['d_price_rival'][1]:+.3f}+-{d['d_price_rival_ci95'][1]:.3f} (per unit {m:+.2f}), "
                  f"gain {d['cum_gain_dev']:+.4f}+-{d['cum_gain_dev_ci95']:.4f}", flush=True)
        out[name] = r


def copy_env(env):
    import copy
    return copy.deepcopy(env)


def llm(out):
    d = os.path.join(ROOT, "results", "llm_bertrand_hike")
    for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        if not f.endswith(".json"):
            continue
        r = json.load(open(os.path.join(d, f)))
        row = {}
        for key in ("deviation_cut", "deviation_hike"):
            t = r.get(key)
            if t:
                # rival_aggression is the FALL in the rival's price per (p_mono - p_nash); deviation_size
                # is the fall in the deviator's price: their ratio is the response per unit, in both directions
                u = t["rival_aggression"][1] / t["deviation_size"]
                uc = abs(t["rival_aggression_ci95"][1] / t["deviation_size"])
                row[key] = {"per_unit": u, "per_unit_ci95": uc, "gain": t["cum_gain_dev"],
                            "gain_ci95": t["cum_gain_dev_ci95"], "size": t["deviation_size"]}
        if row:
            out["llm_" + f[:-5]] = row
            print(f, json.dumps(row), flush=True)


def write_table(out):
    """paper/table_hike.tex: the rival's response per unit of a downward and an upward deviation."""
    pm = lambda m, c, sg="": f"${m:{sg}.2f}_{{\\pm{c:.2f}}}$"  # noqa: E731
    L = ["\\begin{tabular}{@{}lcccc@{}}", "\\toprule",
         " & \\multicolumn{2}{c}{price cut} & \\multicolumn{2}{c}{price rise} \\\\",
         "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}",
         "Agents & response & gain & response & gain \\\\", "\\midrule"]
    pi_n = BertrandMarket(BertrandConfig(), 1, seed=0).bench["pi_nash"]  # gains in units of the Nash profit
    for key, name in (("baseline", "Q-learning, $\\gamma=0.95$"), ("myopic", "Q-learning, $\\gamma=0$")):
        if key in out:
            b, h = out[key]["best_response"], out[key]["hike"]
            L.append(f"{name} & {pm(b['per_unit'], b['per_unit_ci95'])} & "
                     f"{pm(b['cum_gain_dev'] / pi_n, b['cum_gain_dev_ci95'] / pi_n, '+')} & "
                     f"{pm(h['per_unit'], h['per_unit_ci95'])} & "
                     f"{pm(h['cum_gain_dev'] / pi_n, h['cum_gain_dev_ci95'] / pi_n, '+')} \\\\")
    r = out.get("llm_mistral7b_duopoly_k1")
    if r and "deviation_cut" in r and "deviation_hike" in r:
        c, h = r["deviation_cut"], r["deviation_hike"]
        L.append(f"Mistral-7B & {pm(c['per_unit'], c['per_unit_ci95'])} & {pm(c['gain'], c['gain_ci95'], '+')} & "
                 f"{pm(h['per_unit'], h['per_unit_ci95'])} & {pm(h['gain'], h['gain_ci95'], '+')} \\\\")
    L += ["\\bottomrule", "\\end{tabular}"]
    os.makedirs(os.path.join(ROOT, "paper"), exist_ok=True)
    open(os.path.join(ROOT, "paper", "table_hike.tex"), "w").write("\n".join(L) + "\n")


def main():
    path = os.path.join(ROOT, "results", "hike_test.json")
    out = json.load(open(path)) if os.path.exists(path) else {}
    qlearners(out)
    llm(out)
    json.dump(out, open(path, "w"), indent=1)
    macros = {}
    for name, nm in (("baseline", "Q"), ("myopic", "QMyopic")):
        if name in out:
            for mode, md in (("best_response", "BR"), ("hike", "Hike")):
                r = out[name][mode]
                macros[f"Hike{nm}{md}"] = f"{r['per_unit']:.2f}\\pm{r['per_unit_ci95']:.2f}"
                macros[f"Hike{nm}{md}Gain"] = f"{r['cum_gain_dev']:+.3f}"
    r = out.get("llm_mistral7b_duopoly_k1")
    if r:
        for key, md in (("deviation_cut", "Cut"), ("deviation_hike", "Hike")):
            if key in r:
                macros[f"HikeMistral{md}"] = f"{r[key]['per_unit']:.2f}\\pm{r[key]['per_unit_ci95']:.2f}"
                macros[f"HikeMistral{md}Gain"] = f"{r[key]['gain']:+.2f}\\pm{r[key]['gain_ci95']:.2f}"
    write_table(out)
    os.makedirs(os.path.join(ROOT, "paper"), exist_ok=True)
    with open(os.path.join(ROOT, "paper", "numbers_hike.tex"), "w") as fh:
        fh.write("% generated by experiments/hike_test.py\n")
        for k, v in macros.items():
            fh.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")
    print(macros)


if __name__ == "__main__":
    main()
